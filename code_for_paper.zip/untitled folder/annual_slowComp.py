import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

'''
This code creates the method invasion, which simulates competition
between annual plants when some density-dependence occurs next year.
'''

#s= seed survival
#meanG = mean germination
#stdG = standard deviation of germination
#Y = seed yield
#SPP = # of species
#POP1 = the expected population (which sets competition values)
#TIME= how long the simulation runs for
#oldDD = the fraction of density-dependence from the previous year
#printStuff= If true, it prints details about every year
#printFig= If true, it prints a figure at the end

def invasion(s=.6, meanG=.4, stdG=.2, Y=3,\
                  SPP=2,POP1=1000, TIME=20000, \
                  oldDD=.5, printStuff=False, printFig=False):

    #Set up parameters
    POP=POP1*(SPP-1);
    recLam=np.zeros(shape=[TIME+1,SPP]);
    recN=np.zeros(shape=[TIME+1,SPP]);
    recN[0,:]=POP1;
    recN[0,0]=0;

    #q is the competition coeifficent.  here I calculate it to keep
    #population densities about constant.
    beta=1-s*(1-meanG)
    q=(meanG*Y-beta)/(POP*meanG*beta);
    print(f'Competition coefficient is {q}')

    N=np.full(SPP,POP1);
    N[0]=0;

    #Germination at each time step, either a good or bad year with
    # equal probability.
    E1=np.random.binomial(1,.5,[TIME,SPP])
    G=meanG+stdG*(1-2*E1)

    if(np.min(G)<0):
        print('ERROR!!!\nvarG is too big for that meanG')
        quit;

    plantOld=np.sum(N)*Y*meanG;

    #Now run this for TIME time steps
    for t in range(TIME):

        if(printStuff):
            print('\n ==================== \n')
            print(f'N={N}')

        #number of germinants
        plants=N*G[t,:]

        #how much competition reduces fecundity
        comp=1+q*((1-oldDD)*sum(plants)+oldDD*plantOld);


        #lam is the per-capita growth rate
        lam=s*(1-G[t,:])+G[t,:]*Y/comp;
        
        
        N=N*lam;

        recLam[t+1,:]=lam;
        recN[t+1,:]=N;

        plantOld=sum(plants)
        
        if(printStuff):
            print(f'Time {t}')
            print(f'Not germinating={N*(1-G[t,:])}')
            #print(f'survival={survive}')
            print(f'Plants={plants}')
            #print(f'recruitment={recruit}')
            #print(f'total recruit={sum(recruit)}')
            print(f'N={N}')
            #print(f'recoded={recD[t+1,rep]}')

        


    r=np.log(recLam[round(TIME/2):TIME,:])
    growth=np.mean(r,0)
    #print(growth)
             
    if(printFig):
        daX = np.arange(0,TIME+1);
        plt.plot(daX ,recN)
        plt.show();

    return growth[0]
