import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

x=np.load('survival_annual_autoSlow.npz')

results=x['results']
#oldDDval=x['oldDDval']
s=x['s']
Y=x['Y']
TIME=x['TIME']
POP1=x['POP1']
meanG=x['meanG']
stdG=x['stdG']
SPP=x['SPP']
REPS=x['REPS']
repVal=x['repVal']




plt.plot(results,'.-')

plt.xlabel("Autocorrelation");
plt.ylabel("Diversity");

plt.legend(['Fast competition','Fast & slow competition',\
            'Slow competition'])
plt.savefig('annual_autocorrSlow.png')
plt.show()


