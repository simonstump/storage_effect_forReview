import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

delta=.1;
SPP=2;
Evals=np.arange(0,.5,.01)



max_fit=(1-delta)/(SPP-1)*(Evals**2)


plt.plot(Evals,max_fit*100,'k-')
plt.xlabel("Standard deviation of ln(fecundity)");
plt.ylabel("Maximum fecundity difference (percentage)");


plt.savefig('fit_lottery.png')
#plt.show()






FITVAL=.2;
valAt=np.argmax(max_fit>FITVAL);
STDat1=Evals[valAt]


#First I generate two uncorrelated normal random variables.
#This is the Box-Muller transform
seed=34138.13824
seed2=.284018
U1=np.arange(0.001,1,.00001)#.0001)
U2=np.mod(U1*seed+seed2,1)

Evals1=((-2*np.log(U1))**.5)*np.cos(2*np.pi*U2)*STDat1;
Evals2=((-2*np.log(U1))**.5)*np.sin(2*np.pi*U2)*STDat1;

Evals1=Evals1-np.mean(Evals1)
Evals2=Evals2-np.mean(Evals2)

L=len(Evals1)

a=plt.figure();
grow1=np.exp(Evals1-FITVAL);
grow2=np.exp(Evals2);

theX=(max(grow2)-min(grow1))/50
boxes=np.arange(min(grow1),max(grow2),theX)
#boxes=np.arange(.1,2.5,.05)
L=len(boxes)
hist_i=np.zeros(L-1)
hist_r=np.zeros(L-1)

for i in range(L-1):
    hist_i[i]=np.mean((grow2>=boxes[i])&(grow2<boxes[i+1]))
    hist_r[i]=np.mean((grow1>=boxes[i])&(grow1<boxes[i+1]))

box2=boxes[0:(L-1)]
plt.plot(box2,hist_r,'ro-')
plt.plot(box2,hist_i,'go-')

#pylab.xscale('log')
#plt.xlim(0,1)
#plt.ylim(0,1)
plt.xlabel("Fecundity");
plt.ylabel("Frequency");

plt.savefig('fit_lottery_20pctFit.png');

print(f'When there is a fitness difference of {FITVAL*100}%, \
the variance must be {STDat1}, and the weaker species must win at \
\least {np.mean(grow1>grow2)} of the time.')







FITVAL=.05;
valAt=np.argmax(max_fit>FITVAL);
STDat1=Evals[valAt]


#First I generate two uncorrelated normal random variables.
#This is the Box-Muller transform
seed=34138.13824
seed2=.284018
U1=np.arange(0.001,1,.00001)#.0001)
U2=np.mod(U1*seed+seed2,1)

Evals1=((-2*np.log(U1))**.5)*np.cos(2*np.pi*U2)*STDat1;
Evals2=((-2*np.log(U1))**.5)*np.sin(2*np.pi*U2)*STDat1;

Evals1=Evals1-np.mean(Evals1)
Evals2=Evals2-np.mean(Evals2)

L=len(Evals1)

a=plt.figure();
grow1=np.exp(Evals1-FITVAL);
grow2=np.exp(Evals2);

theX=(max(grow2)-min(grow1))/50
boxes=np.arange(min(grow1),max(grow2),theX)
#boxes=np.arange(.1,2.5,.05)
L=len(boxes)
hist_i=np.zeros(L-1)
hist_r=np.zeros(L-1)

for i in range(L-1):
    hist_i[i]=np.mean((grow2>=boxes[i])&(grow2<boxes[i+1]))
    hist_r[i]=np.mean((grow1>=boxes[i])&(grow1<boxes[i+1]))

box2=boxes[0:(L-1)]
plt.plot(box2,hist_r,'ro-')
plt.plot(box2,hist_i,'go-')

#pylab.xscale('log')
#plt.xlim(0,1)
#plt.ylim(0,1)
plt.xlabel("Fecundity");
plt.ylabel("Frequency");

plt.savefig('fit_lottery_5pctFit.png');

print(f'When there is a fitness difference of {FITVAL*100}%, \
the variance must be {STDat1}, and the weaker species must win at \
\least {np.mean(grow1>grow2)} of the time.')







FITVAL=.1;
valAt=np.argmax(max_fit>FITVAL);
STDat1=Evals[valAt]


#First I generate two uncorrelated normal random variables.
#This is the Box-Muller transform
seed=34138.13824
seed2=.284018
U1=np.arange(0.001,1,.00001)#.0001)
U2=np.mod(U1*seed+seed2,1)

Evals1=((-2*np.log(U1))**.5)*np.cos(2*np.pi*U2)*STDat1;
Evals2=((-2*np.log(U1))**.5)*np.sin(2*np.pi*U2)*STDat1;

Evals1=Evals1-np.mean(Evals1)
Evals2=Evals2-np.mean(Evals2)

L=len(Evals1)

a=plt.figure();
grow1=np.exp(Evals1-FITVAL);
grow2=np.exp(Evals2);

theX=(max(grow2)-min(grow1))/50
boxes=np.arange(min(grow1),max(grow2),theX)
#boxes=np.arange(.1,2.5,.05)
L=len(boxes)
hist_i=np.zeros(L-1)
hist_r=np.zeros(L-1)

for i in range(L-1):
    hist_i[i]=np.mean((grow2>=boxes[i])&(grow2<boxes[i+1]))
    hist_r[i]=np.mean((grow1>=boxes[i])&(grow1<boxes[i+1]))

box2=boxes[0:(L-1)]
plt.plot(box2,hist_r,'ro-')
plt.plot(box2,hist_i,'go-')

#pylab.xscale('log')
#plt.xlim(0,1)
#plt.ylim(0,1)
plt.xlabel("Fecundity");
plt.ylabel("Frequency");

plt.savefig('fit_lottery_10pctFit.png');

print(f'When there is a fitness difference of {FITVAL*100}%, \
the variance must be {STDat1}, and the weaker species must win at \
\least {np.mean(grow1>grow2)} of the time.')
