import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile


s=.6
meanG=.4
stdG=.2
Y=3
SPP=10
POP1=10000
TIME=20000
REPS=10
printStuff=False
printFig=True

def survival_time(s=.6, meanG=.4, stdG=.2, Y=3,\
                  SPP=10,POP1=1000, TIME=20000, \
                  REPS=10, printStuff=False, printFig=True):

#if True:

    POP=POP1*SPP;
    recD=np.zeros(shape=[TIME+1,REPS]);
    #recN=np.zeros(shape=[TIME+1,SPP]);
    #recN[0,:]=POP1;

    #q is the competition coeifficent.  here I calculate it to keep
    #population densities about constant.
    beta=1-s*(1-meanG)
    q=(meanG*Y-beta)/(POP*meanG*beta);


    for rep in range(REPS):

        print(f'Replicate #{rep}')
        N=np.full(SPP,POP1);
        for i in range(SPP):
            N[i]=max(int(np.exp(np.random.normal(np.log(POP1),np.log(POP1)/2))), 20)

        #Germination at each time step, either a good or bad year with
        # equal probability.
        E1=np.random.binomial(1,.5,[TIME,SPP])
        G=meanG+stdG*(1-2*E1)
        print(stdG)

        if(np.min(G)<0):
            print('ERROR!!!\nvarG is too big for that meanG')
            break;

        #recD measures diversity at each time step
        recD[0,rep]=SPP;

        for t in range(TIME):

            if(printStuff):
                print('\n ==================== \n')
                print(f'N={N}')

            #number of germinants
            plants=np.random.binomial(N,G[t,:]);

            #how much competition reduces fecundity
            comp=1+q*sum(plants);

            #number of seeds entering seed bank
            recruit=np.random.poisson(Y*plants/comp);


            #print(f'\n\nG={G[t,:]},\nN={N},\ns={s}')
            #survive is seedbank survival
            survive=np.random.binomial(N-plants,s);

            N=survive+recruit;

            recD[t+1,rep]=sum(N>0);
            #recN[t+1,:]=N;
            
            if(printStuff):
                print(f'(Replicate {rep}, time {t}')
                print(f'Not germinating={N*(1-G[t,:])}')
                print(f'survival={survive}')
                print(f'Plants={plants}')
                print(f'recruitment={recruit}')
                print(f'total recruit={sum(recruit)}')
                print(f'N={N}')
                print('recoded={recD[t+1,rep]}')

            


    #daX = np.arange(0,TIME+1);
    #plt.plot(daX ,recN)
    #plt.show();

    if(printFig):
        plt.xlabel("time") ;
        plt.ylabel("density");
        daX = np.arange(0,TIME+1);
        plt.plot(daX ,np.mean(recD,1))
        plt.show();

    return recD
