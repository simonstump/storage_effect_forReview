import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt

fileName='save_strength_plankton'

DIF=.1;
delta=.4;
Rin=1;
c=1;
a=1

plotIt=True;

stdVals=np.arange(0.001,.4,.001)

results=np.zeros(len(stdVals))

import mechStrength_plankton as plank

for i in range(len(stdVals)):
      print(f'{round(100*i/len(stdVals))}% complete')
      results[i]=plank.invader_growth(DIF=DIF, c=1,a=1,delta=delta, Rin=Rin,\
                                   STD=stdVals[i],plotIt=False);


#print(results)



#When effects are equal
STD1=.1;
valAt=np.argmax(stdVals==STD1);

mechEqual=(results[valAt]-results[0])/results[0]

seed=34138.13824
seed2=.284018
Evals1=np.arange(0,1.000001,.001)#.0001)
Evals2=np.mod(Evals1*seed+seed2,1)
Evals2=Evals2-np.mean(Evals2)+.5


#The conversion rates on the resource limiting the resident
c_low = c*(1-DIF) + 2*STD1*Evals1 - STD1
c_high = c + 2*STD1*Evals2 - STD1

#How often the resident is better on its worst resource
benEqual=np.mean(c_high<c_low)
print(valAt)
val10=valAt;
print(f'The mechanism is at {mechEqual} strength when STD={STD1}, and sp. 1 is strictly better than sp. 2 {benEqual*100}% of the time')






#10% advantage at...
val=results/results[0];
valAt=np.argmax(val>1.1);

STD=stdVals[valAt]

seed=34138.13824
seed2=.284018
Evals1=np.arange(0,1.000001,.001)#.0001)
Evals2=np.mod(Evals1*seed+seed2,1)
Evals2=Evals2-np.mean(Evals2)+.5


#The conversion rates on the resource limiting the resident
c_low = c*(1-DIF) + 2*STD*Evals1 - STD
c_high = c + 2*STD*Evals2 - STD

#How often the resident is better on its worst resource
ben10at=np.mean(c_high<c_low)
                 
print(valAt)
val10=valAt;
STD10=STD;
print(f'The mechanism is at 50% strength when STD={STD}, and sp. 1 is strictly better than sp. 2 {ben10at*100}% of the time')

#50% advantage at
val=results/results[0];
valAt=np.argmax(val>1.5);

STD=stdVals[valAt]

seed=34138.13824
seed2=.284018
Evals1=np.arange(0,1.000001,.001)#.0001)
Evals2=np.mod(Evals1*seed+seed2,1)
Evals2=Evals2-np.mean(Evals2)+.5

#The conversion rates on the resource limiting the resident
c_low = c*(1-DIF) + 2*STD*Evals1 - STD
c_high = c + 2*STD*Evals2 - STD

#How often the resident is better on its worst resource
ben50at=np.mean(c_high<c_low)
print(valAt)
val50=valAt;
STD50=STD
print(f'The mechanism is at 50% strength when STD={STD}, and sp. 1 is strictly better than sp. 2 {ben50at*100}% of the time')


##
###100% advantage at
##val=results/results[0];
##valAt=np.argmax(val>2);
##
##STD=stdVals[valAt]
##
##seed=34138.13824
##seed2=.284018
##Evals1=np.arange(0,1.000001,.001)#.0001)
##Evals2=np.mod(Evals1*seed+seed2,1)
##Evals2=Evals2-np.mean(Evals2)+.5
##
###The conversion rates on the resource limiting the resident
##c_low = c*(1-DIF) + 2*STD*Evals1 - STD
##c_high = c + 2*STD*Evals2 - STD
##
###How often the resident is better on its worst resource
##ben100at=np.mean(c_high<c_low)
##                
##print(valAt)
##val100=valAt;
##STD100=STD
##print(f'The mechanism is at 100% strength when STD={STD100}, and sp. 1 is strictly better than sp. 2 {ben100at}% of the time')



##saving everything
np.savez(fileName+'.npz', results=results, DIF=DIF, delta=delta, Rin=Rin, \
         stdVals=stdVals, STD10=STD10,val10=val10,ben10at=ben10at,\
         STD50=STD50,val50=val50,ben50at=ben50at,benEqual=benEqual,\
         mechEqual=mechEqual)



