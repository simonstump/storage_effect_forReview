import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt

E0=1.2
NUM=100;
E=np.ones([NUM,1])*.9
E[0]=E0
#E=E/np.mean(E)

N=np.ones([NUM,1])
N=N/np.mean(N)


d=.1#3

TIME=200


for t in range(TIME):

    grow=N*E;

    toN=grow*(1-d)+d*np.mean(grow)

    N=toN/np.sum(toN)

    print(f'At time={t}, N1/N2={round(np.double(N[0]/np.mean(N)),4)}')
    


meanFit = np.mean(E)
meanDen = 1

FD=E*N/np.mean(N)
meanFD = np.mean(FD)

fdCov = meanFD-meanFit*meanDen

meanGrow=np.sum(grow)

print(f'The FD-cov is {fdCov}; mean growth is {meanGrow}')


print(f'Growth with temporal variation would be {np.exp(np.mean(np.log(E)))}')
