import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt

'''
Run this code to generate the results for Fig. 2B.
'''

fileName='save_lizard_model_results'

import lizard_model as liz

REPS=10;

Avals=np.arange(-5,5.001,.25)
logVal=2;

meanN=200;
delta=.3;
Evar=.5;


results=np.zeros([len(Avals),REPS])


for i in range(len(Avals)):
    for j in range(REPS):
        print(f'Value {logVal**Avals[i]}, REP={j}')
        results[i,j]=liz.lizard_model(meanN=meanN, delta=delta, \
                                  adultVjuv=logVal**Avals[i], Evar=Evar);


zeroVal=np.zeros(REPS)
for i in range(REPS):
    print(f'Value 0, REP={i}')
    zeroVal[i]=liz.lizard_model(meanN=meanN, delta=delta, \
                                  adultVjuv=10**-20, Evar=Evar);


res=np.mean(results,1)
res0=np.mean(zeroVal)

np.savez(fileName+'.npz', results=results, Avals=Avals, meanN=meanN, \
         delta=delta, Evar=Evar, REPS=REPS, res=res, res0=res0,\
         zeroVal=zeroVal)

plt.plot(Avals,res,'ko-',Avals,Avals*0+res0/2,'r--')
plt.show()
