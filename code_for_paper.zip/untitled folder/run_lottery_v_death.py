import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile


fileName='save_var_lotteryVdeath_10spp'

SPP=10;

REPS=50;

VARVAL=.1

if SPP==10:
   REPS=50;
   TIME1=10**3;   #Time I run the model for
   POP1=500;    #The per-species carrying capacity.
   fileName='save_var_lotteryVdeath_10spp';
   deaths=np.arange(.05,.501,.05);
   Evars=np.array([0,.1, .5])#np.arange(0.05,.551,.1);
else:
   REPS=25;
   TIME1=10**3;
   POP1=500#1000;
   fileName='save_var_lotteryVdeath_2spp'
   deaths=np.array([.2, .3, .4, .5, .6]);
   Evars=np.array([0,.1, .4])#np.arange(0.05,.551,.1);




#This is the strength of each mechanism

#deaths=np.arange(.1,.551,.1);
#Evars=np.arange(0.05,.551,.1);


###uncomment for testing purposes
###TIME1=10**3;   #-> for 10spp
###POP1=500;   #-> for 10spp
##
##TIME1=10**4
##POP1=1000;
##REPS=10;
##deaths=np.arange(.1,.551,.2);
##Evars=np.arange(0.1,.651,.1);


results=np.zeros([len(Evars),len(deaths)])

import survival_time_storage as stor
#import survival_time_neutral as newt

for j in range(len(Evars)):
   VAR_E=Evars[j];
   for i in range(len(deaths)):
        death=deaths[i];
        TIME=int(round(TIME1/death));

        print(f'=========\nVar= {VAR_E}, Death = {death}, TIME={TIME}')
        #storage=newt.survival_time(death=death, \
        storage=stor.survival_time(death=death, VAR_E=VAR_E,\
                         SPP=SPP, REPS=REPS, TIME=TIME, POP1=POP1,\
                         printStuff=False, printFig=False);
        print(f'Survival = {np.mean(storage[len(storage)-1,:])}')
        results[j,i]=np.mean(storage[len(storage)-1,:])


print(results)


##saving everything
np.savez(fileName+'.npz', results=results, Evars=Evars, deaths=deaths, \
         TIME1=TIME1, POP1=POP1, SPP=SPP, REPS=REPS)


##plt.xlabel("death") ;
##plt.ylabel("alive");
##for i in range(len(Evars)):
##   plt.plot(deaths ,results[i,:],'o-')
##
##plt.legend(Evars)
##plt.show();


