import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt

'''
This runs the code for Fig. S6.
'''



REPS=100
s=.6
meanG=.4
stdG=.2
Y=3
SPP=10
POP1=1000
TIME=1000
REPS=100
oldDDval=np.array([1, .5, 0])
printStuff=False
printFig=True
repVal=np.array([1, 2, 3, 4, 5, 6])
                      

fileName='survival_annual_autoSlow'

results=np.zeros([len(repVal),len(oldDDval)])

import survival_time_annual_slowAuto as ann


for j in range(len(oldDDval)):

   for i in range(len(repVal)):

      alive=ann.survival_time(s=s, meanG=meanG,\
                      stdG=stdG,Y=Y,repeatTime=int(repVal[i]), \
                      SPP=SPP, oldDD=oldDDval[j], REPS=REPS, TIME=TIME, POP1=POP1,\
                      printStuff=False, printFig=False)

      print(f"{i}, {j} = {np.mean(alive[len(alive)-1,:])}")
      results[i,j]=np.mean(alive[len(alive)-1,:])




##saving everything
np.savez(fileName+'.npz', results=results, oldDDval=oldDDval, s=s, Y=Y, TIME=TIME,\
         POP1=POP1, meanG=meanG, stdG=stdG, SPP=SPP, REPS=REPS, repVal=repVal)


print(results)


plt.plot(results)
plt.show()
