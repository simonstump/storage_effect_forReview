import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

'''
Run this to draw Fig. S2.
'''


x=np.load('save_annual_autocorr.npz')

results=x['results']
s=x['s']
meanG=x['meanG']
stdG=x['stdG']
POP1=x['POP1']
SPP=x['SPP']
TIME=x['TIME']
Y=x['Y']
REPS=x['REPS']
oldDD=x['oldDD']
res=x['res']
theseRepTimes=x['theseRepTimes']
results2=x['results2']
oldDD2=x['oldDD2']



res=np.mean(results,1)
res2=np.mean(results2,1)


plt.plot(theseRepTimes,res,'ko-')
plt.plot(theseRepTimes,res2,'ro-')

plt.xlabel("Autocorrelation");
plt.ylabel("Invader growth rate");

plt.legend(['Slow density-dependence','Fast density-dependnece'])
plt.savefig('annual_autocorr.png')
plt.show()


