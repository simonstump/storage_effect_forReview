import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt

x=np.load('save_strength_plankton.npz')

results=x['results']
DIF=x['DIF']
delta=x['delta']
Rin=x['Rin']
stdVals=x['stdVals']
STD10=x['STD10']
val10=x['val10']
ben10at=x['ben10at']
STD50=x['STD50']
val50=x['val50']
ben50at=x['ben50at']
benEqual=x['benEqual']
mechEqual=x['mechEqual']



import mechStrength_plankton as plank


plt.xlabel("Uptake rate variation",fontsize=14);
plt.ylabel("Stabilizing mechanism",fontsize=14);

plt.plot(stdVals/DIF ,results,'o-')
#plt.xscale('log')

plt.ylim(0,max(results)+.03)


plt.savefig(f'storageVresource.png')
plt.show()

##plank.invader_growth(DIF=DIF, delta=delta, Rin=Rin,STD=.05,plotIt=True,\
##                       plotName='storageVresource05.png');


plank.invader_growth(DIF=DIF, delta=delta, Rin=Rin,STD=.1,plotIt=True,\
                       plotName='storageVresource1.png');

print(f'The mechanism is at {round(mechEqual*100,1)}% strength when STD=0.1, and sp. 1 is strictly better than sp. 2 {benEqual*100}% of the time')


##plank.invader_growth(DIF=DIF, delta=delta, Rin=Rin,STD=.2,plotIt=True,\
##                       plotName='storageVresource2.png');
##
##plank.invader_growth(DIF=DIF, delta=delta, Rin=Rin,STD=.3,plotIt=True,\
##                       plotName='storageVresource3.png');
##
##plank.invader_growth(DIF=DIF, delta=delta, Rin=Rin,STD=.15,plotIt=True,\
##                       plotName='storageVresource15.png');
##
##plank.invader_growth(DIF=DIF, delta=delta, Rin=Rin,STD=.25,plotIt=True,\
##                       plotName='storageVresource25.png');



plank.invader_growth(DIF=DIF, delta=delta, Rin=Rin,STD=STD10,plotIt=True,\
                       plotName='storageVresource_10ben.png');

print(val10)
print(f'The mechanism is at 50% strength when STD={STD10}, and sp. 1 is strictly better than sp. 2 {ben10at*100}% of the time')

#50% advantage at

plank.invader_growth(DIF=DIF, delta=delta, Rin=Rin,STD=STD50,plotIt=True,\
                       plotName='storageVresource_50ben.png');

print(val50)
print(f'The mechanism is at 50% strength when STD={STD50}, and sp. 1 is strictly better than sp. 2 {ben50at*100}% of the time')


