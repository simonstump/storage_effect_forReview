import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt


printStuff=False


#Here are the parameters for the deer/lizard model.

meanN=100;
delta=.3;
adultVjuv=10; #if this is 3, then 1 adult has the same impact as 3 juveniles.
Evar=.5
INVASION=True

def lizard_model(meanN=100, delta=.3, adultVjuv=10, Evar=.5, \
                 INVASION=True,printStuff=False):

#if(True):

    alphaA=-adultVjuv*np.log(delta)/(meanN*(1+adultVjuv));
    alphaJ=alphaA/adultVjuv;


    N=[0, meanN]

    if(INVASION):
        N=[0,meanN]
        TIME=20000;
    else:
        N=[meanN/2,meanN/2]
        TIME=200;


    #This is the growth response each year.
    #E[i,j] is the E value for sp. j in year i.
    E=np.random.normal(0,Evar,[TIME,2])


##    U0=np.arange(1/TIME,1+(.9/TIME),1/TIME)#.0001)
##
##    seedX=11571.5972
##    seed2X=.4297501
##    U1=np.mod(U0*seedX+seed2X,1)
##
##    seed=34134.13824
##    seed2=.274018    
##    U2=np.mod(U0*seed+seed2,1)
##
##    Evals1=((-2*np.log(U1))**.5)*np.cos(2*np.pi*U2)*Evar;
##    Evals2=((-2*np.log(U1))**.5)*np.sin(2*np.pi*U2)*Evar;
##
##    E1=Evals1-np.mean(Evals1)
##    E2=Evals2-np.mean(Evals2)
##
##    E=np.column_stack([E1,E2])


    Nrecord=np.zeros(shape=[TIME,2])
    lamrecord=np.zeros(shape=[TIME,2])
    birthRecord=np.zeros(shape=[TIME,2]);
    compRecord=np.zeros(shape=[TIME,2]);


    for t in range(TIME):

        if(printStuff):
            print('\n ==================== \n')
            print(f'N={N}')
            print(f'E(t)={E[t,:]}')

        #Amount of competition that year
        compA=alphaA*sum(N)
        compJ=alphaJ*sum(N*(np.exp(E[t,:])));

        #number of tadpoles that recruit per capita
        births=np.exp(E[t,:]-compA-compJ);

        lam=1-delta+births

        N=N*lam

        Nrecord[t,:]=N;
        lamrecord[t,:]=lam;
        birthRecord[t,:]=births;
        compRecord[t,0]=compA;
        compRecord[t,1]=compJ;
        
        if(printStuff):
            print(f'comp={compA}, {compJ}')
            print(f'births={births}')
            print(f'lambda={lam}')
            print(f'N={N}')

        

        
    #print(N)


    if(INVASION):
        r=sum(np.log(lamrecord))/TIME;
        #print(f'mean {np.exp(r)}')
        return r[0]
    else:
        plt.xlabel("time") ;
        plt.ylabel("density");
        daX = np.arange(0,TIME);
        plt.plot(daX ,Nrecord)
        plt.show();
        return N
