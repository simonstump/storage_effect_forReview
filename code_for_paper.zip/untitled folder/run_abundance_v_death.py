import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt


##This code runs the stochastic models at several abundances
## to test the impact of abundance on stochastic survival.


death=.3#.5;

fileName='save_abundance_v_death'


SPP=10;

#mean population size of 500 per species.

#100,000 generations
TIME=round((3*10**4)/death);

REPS=25;
REPS=100
REPS=25
Nval=np.arange(np.log(200),np.log(100000),.65);


#####uncomment for testing purposes
##TIME=round(10**3.5/death);
##REPS=3#25#10;
##Nval=np.arange(np.log(500),np.log(2000),.45);


#This is the strength of each mechanism
MECH_STRENGTH=.3;



print('Storage')
resultsStorage=np.zeros([len(Nval),TIME+1])

import survival_time_storage as stor
for i in range(len(Nval)):
    print(int(np.exp(Nval[i])))
    storage=stor.survival_time(death=death, VAR_E=(MECH_STRENGTH/(1-death)),\
                     SPP=SPP, REPS=REPS, TIME=TIME, POP1=int(np.exp(Nval[i])),\
                     printStuff=False, printFig=False)
    resultsStorage[i,:]=np.mean(storage,1)

print('Neutral')
import survival_time_neutral as neut
resultsNeutral=np.zeros([len(Nval),TIME+1])
for i in range(len(Nval)):
    print(int(np.exp(Nval[i])))
    neutral=neut.survival_time(death=death, \
                     SPP=SPP, REPS=REPS, TIME=TIME, POP1=int(np.exp(Nval[i])),\
                     printStuff=False, printFig=False)
    resultsNeutral[i,:]=np.mean(neutral,1)





print('JC effects')
import survival_time_JC as JC
resultsPredators=np.zeros([len(Nval),TIME+1])
for i in range(len(Nval)):
    print(int(np.exp(Nval[i])))
    predators=JC.survival_time(death=death, alpha=MECH_STRENGTH,\
                     SPP=SPP, REPS=REPS, TIME=TIME, POP1=int(np.exp(Nval[i])),\
                     printStuff=False, printFig=False)
    resultsPredators[i,:]=np.mean(predators,1)



##saving everything

np.savez(fileName+'.npz', resultsStorage=resultsStorage, \
         resultsNeutral=resultsNeutral,\
         resultsPredators=resultsPredators,\
         Nval=Nval, \
         TIME=TIME, death=death, MECH_STRENGTH=MECH_STRENGTH)


##
##
##plt.xlabel("time") ;
##plt.ylabel("diversity");
##daX=np.arange(0,TIME+1,1);
##for i in range(len(Nval)):
##    plt.plot(daX ,resultsStorage[i,:],'k-')
##    plt.plot(daX ,resultsNeutral[i,:],'b-')
##    plt.plot(daX ,resultsPredators[i,:],'g-')
##plt.show();
##

plt.xlabel("abundance") ;
plt.ylabel("diversity");
plt.plot(Nval ,resultsStorage[:,TIME],'k-')
plt.plot(Nval ,resultsNeutral[:,TIME],'b-')
plt.plot(Nval ,resultsPredators[:,TIME],'g-')
plt.show();
##



