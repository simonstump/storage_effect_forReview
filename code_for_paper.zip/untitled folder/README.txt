
Fig 2b:
run_lizard_model.py - This runs the code needed, and saves the output as save_lizard_model_results.npz.
run_lizard_model.py- This contains a method that simulates the lizard model.  
drawfig2_lizard_model.py- This draws Fig 2b.

Fig 3:
run_strength_plankton.py - This runs some of the code needed (the long parts), and saves the output as save_strength_plankton.npz.
mechStrength_plankton.py- This contains a method that simulates plankton competition.  
drawfig3_lizard_model.py- This draws Fig 3b from data, and also mechStrength_plankton.py several times quickly to generate data and draw Fig 3c, 3d, and 3e.  It also calculates numbers discussed in the text.

Fig 4:
drawfig4_fit_lottery.py - This runs internal code and generates Fig. 4.  It also generates numbers discussed in the text.

Fig 5:
run_mech_survive.py - This runs the code needed, and saves the output as save_var_multiMechs_death?.npz, where the ? is 10 times the survival rate (i.e. 2 when it is 0.2).  At the start of this code, it asks you to give it a survival rate.  It is currently set to 0.5, which would generate Fig 5a.  To generate Fig. 5b, set it to 0.2.
survival_time_habitat.py- This contains a method that simulates competition between tropical trees with stochastic births and deaths, when diversity is maintained by habitat partitioning.
survival_time_JC.py- This contains a method that simulates competition between tropical trees with stochastic births and deaths, when diversity is maintained by specialized predation.
survival_time_neutral.py- This contains a method that simulates competition between tropical trees with stochastic births and deaths, when diversity is not maintained by any mechanism.
survival_time_storageJC.py- This contains a method that simulates competition between tropical trees with stochastic births and deaths, when diversity is maintained by the storage effect and predator partitioning.
survival_time_storage.py- This contains a method that simulates competition between tropical trees with stochastic births and deaths, when diversity is maintained by the storage effect.
drawfig5_diff_mechs.py - This draws Fig 5.



Fig S1:
run_annual_slowComp.py - This runs the code needed, and saves the output as save_annual_slowComp.npz
annual_slowComp.py - This contains a method that simulates competition between annual plants when some density-dependence is delayed.
drawfigS1_annual_slowComp.py - This draws Fig S1.


Fig S2:
run_annual_autoCorr.py - This runs the code needed, and saves the output as save_annual_autocorr.npz
annual_slowComp_autocorr.py - This contains a method that simulates competition between annual plants when some density-dependence is delayed, and the environment is autocorrelated.
draw_autocorr_annual.py - This draws Fig S2.


Fig S3:
run_lizard_autoCorr.py.py - This runs the code needed, and saves the output as save_lizard_autocorr.npz
lizard_model_autocorr.py - This contains a method that simulates competition between lizards when some density-dependence is delayed.
drawfigS3_autocorr_lizard.py - This draws Fig S3.


Fig S4:
run_abundance_v_death.py - This runs the code needed, and saves the output as save_abundance_v_death.npz
survival_time_JC.py- This contains a method that simulates competition with stochastic births and deaths, where diversity is maintained by predator partitioning.  
survival_time_neutral.py- This contains a method that simulates competition with stochastic births and deaths, where diversity is not maintained by any stabilizing mechanisms.  
survival_time_storage.py- This contains a method that simulates competition with stochastic births and deaths, where diversity is maintained by by the storage effect.  
drawfigS4_abundanceVdeath.py- This draws Fig S4.


Fig S5:
run_lottery_v_death.py - This runs the code needed, and saves the output as save_abundance_v_death.npz
survival_time_storage.py- This contains a method that simulates competition with stochastic births and deaths, where diversity is maintained by by the storage effect.  
drawfigS5_lotteryVdeath.py- This draws Fig S5.


Fig S6:
run_annual_v_autocorrSlow.py - This runs the code needed, and saves the output as survival_annual_autoSlow.npz
survival_time_annual_slowAuto.py- This contains a method that simulates an annual plant model with stochastic births and deaths, where diversity is maintained by by the storage effect, and where density-dependence can be slow.  
drawfigS6_annual_surviveAutocorr.py- This draws Fig S6.



Fig S7:
run_annual_survive_data.py - This runs the code needed, and saves the output as save_annual_survive.npz.
survival_time_annual_data.py- This contains the data to parameterize a model with values appropriate for each community.  Once run, it also calls survival_time_annual.py.
survival_time_annual.py- This contains a method that simulates an annual plant model with stochastic births and deaths, where diversity is maintained by by the storage effect.  
drawfigS7_annual_surviveData.py- This draws Fig S7.

Fig S8:
run_lizard_survival.py - This runs the code needed, and saves the output as save_var_lizard_death.npz.
survival_time_lizards.py- This contains a method that simulates the lizard model with stochastic births and deaths, where diversity is maintained by by the storage effect.  
drawfigS8_lizard_survival.py- This draws Fig S8.



Other analysis:
recreate_chessonKuang.py - This runs our analysis in section S3.3, showing the mathematical flaws of the Chesson & Kuang (2010) model.  Run it by itself, and it tells you the values discussed in the paper.  

FDcov_theory2.py - This runs our analysis of discussed in section S4.2 of the appendix, why species can specialize in habitat but not time.  

analyze_annual_plants.py- This runs the analysis discussed in S6.1 of the appendix, on an estimate for inter- vs. intra-specific competition effects in annual plants.  It uses data from Godoy et al (2014), which is saved in the tables godoy_alpha.csv and godoy_speciesvitalrates.csv.  

