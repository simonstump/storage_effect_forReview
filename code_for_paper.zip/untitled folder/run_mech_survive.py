import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt



death=.5;

fileName='save_var_multiMechs_death'+str(round(death*10))


SPP=10;

#mean population size of 500 per species.
POP1=500;

#100,000 generations
#TIME=round((10**5)/death);
TIME=round((10**4)/death);

REPS=25;
REPS=100

###uncomment for testing purposes
##TIME=round(10**4/death);
##POP1=500;
##REPS=5#25#10;

#This is the strength of each mechanism
MECH_STRENGTH=.3;


print('Storage')
import survival_time_storage as stor
storage=stor.survival_time(death=death, VAR_E=(MECH_STRENGTH/(1-death)),\
                     SPP=SPP, REPS=REPS, TIME=TIME, POP1=POP1,\
                     printStuff=False, printFig=False)

print('Neutral')
import survival_time_neutral as neut

neutral=neut.survival_time(death=death, \
                     SPP=SPP, REPS=REPS, TIME=TIME, POP1=POP1,\
                     printStuff=False, printFig=False)




print('JC effects')
import survival_time_JC as JC

predators=JC.survival_time(death=death, alpha=MECH_STRENGTH,\
                     SPP=SPP, REPS=REPS, TIME=TIME, POP1=POP1,\
                     printStuff=False, printFig=False)


print('Habitat partitioning')
import survival_time_habitat as hab

habitat=hab.survival_time(death=death, VAR_E=MECH_STRENGTH,\
                     SPP=SPP, REPS=REPS, TIME=TIME, POP1=POP1,\
                     printStuff=False, printFig=False)

print('Storage and JC effects')
import survival_time_storageJC as both

multi=both.survival_time(death=death, VAR_E=MECH_STRENGTH/(1-death)/2,\
                     alpha=MECH_STRENGTH/2,\
                     SPP=SPP, REPS=REPS, TIME=TIME, POP1=POP1,\
                     printStuff=False, printFig=False)



##saving everything

np.savez(fileName+'.npz', storage=storage, neutral=neutral, \
         predators=predators, habitat=habitat, multi=multi, \
         TIME=TIME, death=death, MECH_STRENGTH=MECH_STRENGTH)



##
##plt.xlabel("time") ;
##plt.ylabel("density");
##daX = np.arange(0,TIME+1)*death;
##plt.plot(daX ,np.mean(storage,1),'k-')
##plt.plot(daX ,np.mean(neutral,1),'b-')
##plt.plot(daX ,np.mean(predators,1),'g-')
##plt.plot(daX ,np.mean(habitat,1),'c-')
##plt.plot(daX ,np.mean(multi,1),'m-')
##plt.show();
##

