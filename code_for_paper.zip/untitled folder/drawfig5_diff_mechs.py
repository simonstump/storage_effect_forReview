import pandas as pd
import numpy as np
import math
import pylab
from matplotlib import pyplot as plt



NUM=2
data=np.load('save_var_multiMechs_death2.npz')

storage=data['storage']
neutral=data['neutral']
predators=data['predators']
habitat=data['habitat']
multi=data['multi']
death=data['death']

TIME=len(storage)

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

daX = np.arange(0,TIME)*death;
ax.plot(daX ,np.mean(storage,1),'k-')
ax.plot(daX ,np.mean(neutral,1),'b-')
ax.plot(daX ,np.mean(predators,1),'g-')
ax.plot(daX ,np.mean(habitat,1),'c-')
ax.plot(daX ,np.mean(multi,1),'m-')
#daX = np.arange(0,TIME);
for i in range(100):
    ax.plot(daX,storage[:,i],'k-',linewidth=.1)
    ax.plot(daX,neutral[:,i],'b-',linewidth=.1)
    ax.plot(daX,predators[:,i],'g-',linewidth=.1)
    ax.plot(daX,habitat[:,i],'c-',linewidth=.1)
    ax.plot(daX,multi[:,i],'m-',linewidth=.1)

ax.plot(daX ,np.mean(storage,1),'k-')
ax.plot(daX ,np.mean(neutral,1),'b-')
ax.plot(daX ,np.mean(predators,1),'g-')
ax.plot(daX ,np.mean(habitat,1),'c-')
ax.plot(daX ,np.mean(multi,1),'m-')

ax.set_xscale('log')
plt.xlabel('Time (generations)',fontsize=14)
plt.ylabel('Species richness',fontsize=14)

plt.xlim(10,TIME*death)

daNames=['Storage effect','Neutral model',\
                   'Predator partitioning','Habitat partition',\
                   'Storage + pred partitioning']

plt.legend(labels=daNames)
plt.title(f'Diversity over time when death=0.{NUM}')
plt.savefig(f'multi_mechs_{NUM}.png')
plt.show()


NUM=5
data=np.load('save_var_multiMechs_death5.npz')

storage=data['storage']
neutral=data['neutral']
predators=data['predators']
habitat=data['habitat']
multi=data['multi']
death=data['death']

TIME=len(storage)

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

daX = np.arange(0,TIME)*death;
#daX = np.arange(0,TIME);
ax.plot(daX ,np.mean(storage,1),'k-')
ax.plot(daX ,np.mean(neutral,1),'b-')
ax.plot(daX ,np.mean(predators,1),'g-')
ax.plot(daX ,np.mean(habitat,1),'c-')
ax.plot(daX ,np.mean(multi,1),'m-')

for i in range(100):
    ax.plot(daX,storage[:,i],'k-',linewidth=.1)
    ax.plot(daX,neutral[:,i],'b-',linewidth=.1)
    ax.plot(daX,predators[:,i],'g-',linewidth=.1)
    ax.plot(daX,habitat[:,i],'c-',linewidth=.1)
    ax.plot(daX,multi[:,i],'m-',linewidth=.1)


ax.plot(daX ,np.mean(storage,1),'k-')
ax.plot(daX ,np.mean(neutral,1),'b-')
ax.plot(daX ,np.mean(predators,1),'g-')
ax.plot(daX ,np.mean(habitat,1),'c-')
ax.plot(daX ,np.mean(multi,1),'m-')

ax.set_xscale('log')
plt.xlabel('Time (generations)',fontsize=14)
plt.ylabel('Species richness',fontsize=14)

plt.xlim(10,TIME*death)

daNames=['Storage effect','Neutral model',\
                   'Predator partitioning','Habitat partition',\
                   'Storage + pred partitioning']

plt.legend(labels=daNames)
plt.title(f'Diversity over time when death=0.5')
plt.savefig(f'multi_mechs_5.png')
plt.show()
