import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
import survival_time_lizards as liz



fileName='save_var_lizard_death'


Evar=.2
Evar2=.4
adultVjuv=1/5

adultVjuv2=1.5




delta = np.sort(1-np.array([.11, .20, .27, .49, .07, .34, .44, .37, .48, .6, .7, .8, .85, .9]))

SPP=5

#mean population size of 500 per species.
meanN=2000;

#GENS is the number of generations, which becomes years in TIME
GENS=300
TIME=np.round((GENS)/delta);

REPS=500

###uncomment for testing purposes
##TIME=round(10**4/death);
##POP1=500;
##REPS=5#25#10;

#This is the strength of each mechanism

result_storage = np.zeros([REPS,len(delta)])
result_storage2 = np.zeros([REPS,len(delta)])
result_neutral = np.zeros([REPS,len(delta)])

result_storageX = np.zeros([REPS,len(delta)])
result_storage2X = np.zeros([REPS,len(delta)])
result_neutralX = np.zeros([REPS,len(delta)])

for d in range(len(delta)):
    print(f"death rate={delta[d]}")
    for i in range(REPS):
        result_storage[i,d]=liz.lizard_model(meanN=meanN,\
                                             delta=delta[d],\
                                             adultVjuv=adultVjuv,\
                                             Evar=Evar,\
                                             TIME=np.int(TIME[d]),\
                                             SPP=SPP)

        result_storage2[i,d]=liz.lizard_model(meanN=meanN,\
                                             delta=delta[d],\
                                             adultVjuv=adultVjuv,\
                                             Evar=Evar2,\
                                             TIME=np.int(TIME[d]),\
                                             SPP=SPP)

        result_neutral[i,d]=liz.lizard_model(meanN=meanN,\
                                             delta=delta[d],\
                                             adultVjuv=adultVjuv,\
                                             Evar=0,\
                                             TIME=np.int(TIME[d]),\
                                             SPP=SPP)

        result_storageX[i,d]=liz.lizard_model(meanN=meanN,\
                                             delta=delta[d],\
                                             adultVjuv=adultVjuv2,\
                                             Evar=Evar,\
                                             TIME=np.int(TIME[d]),\
                                             SPP=SPP)

        result_storage2X[i,d]=liz.lizard_model(meanN=meanN,\
                                             delta=delta[d],\
                                             adultVjuv=adultVjuv2,\
                                             Evar=Evar2,\
                                             TIME=np.int(TIME[d]),\
                                             SPP=SPP)

        result_neutralX[i,d]=liz.lizard_model(meanN=meanN,\
                                             delta=delta[d],\
                                             adultVjuv=adultVjuv2,\
                                             Evar=0,\
                                             TIME=np.int(TIME[d]),\
                                             SPP=SPP)



##saving everything

np.savez(fileName+'.npz', storage=result_storage, neutral=result_neutral, \
         storage2=result_storage2,\
         storageX=result_storageX, neutralX=result_neutralX,\
         storage2X=result_storage2X,\
         Evar2=Evar2,\
         TIME=TIME, delta=delta, Evar=Evar, adultVjuv=adultVjuv, SPP=SPP, \
         meanN=meanN, GENS=GENS)






plt.xlabel("time") ;
plt.ylabel("density");
plt.plot(delta ,np.mean(result_storage,0),'ko-')
plt.plot(delta ,np.mean(result_storage2,0),'ro-')
plt.plot(delta ,np.mean(result_neutral,0),'bo-')
plt.show();


