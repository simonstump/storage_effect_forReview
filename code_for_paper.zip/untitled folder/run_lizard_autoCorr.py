import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

fileName='save_lizard_autocorr';



meanN=100
delta=.3
Evar=.5
INVASION=True
adultVjuv=5
adultVjuv2=.2

REPS=100;

theseRepTimes=np.array([1,2,3,4, 5,6])

import lizard_model_autocorr as liz

results=np.zeros([len(theseRepTimes),REPS])

for r in range(REPS):
    print(f'Rep={r}')
    for i in range(len(theseRepTimes)):
        results[i,r]=liz.lizard_model(repeatTime=int(theseRepTimes[i]),\
                                  meanN=meanN, delta=delta, Evar=Evar, \
                                  adultVjuv=adultVjuv, INVASION=True)
                                  

res=np.mean(results,1)

results2=np.zeros([len(theseRepTimes),REPS])
for r in range(REPS):
    print(f'Rep={r}')
    for i in range(len(theseRepTimes)):
        results2[i,r]=liz.lizard_model(repeatTime=int(theseRepTimes[i]),\
                                  meanN=meanN, delta=delta, Evar=Evar, \
                                  adultVjuv=adultVjuv2, INVASION=True)
res2=np.mean(results2,1)


##saving everything
np.savez(fileName+'.npz', results=results, results2=results2, meanN=meanN,\
         delta=delta, Evar=Evar, adultVjuv=adultVjuv, adultVjuv2=adultVjuv2,\
         theseRepTimes=theseRepTimes)

##
plt.plot(theseRepTimes,res,'ko-')
plt.plot(theseRepTimes,res2,'ro-')
plt.show()
