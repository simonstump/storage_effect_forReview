import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

'''
Run this code to generate the data needed for Fig. S2.
'''


fileName='save_annual_autocorr';

s=.6;
meanG=.5;
stdG=.2;
POP1=1000
SPP=3;
TIME=20000;
Y=3;
printStuff=False;
printFig=False;
oldDD=.7;

oldDD2=0;

REPS=100;

theseRepTimes=np.array([1,2,4, 5,8, 10])

import annual_slowComp_autocorr as ann

results=np.zeros([len(theseRepTimes),REPS])

for r in range(REPS):
    print(f'Rep={r}')
    for i in range(len(theseRepTimes)):
        results[i,r]=ann.invasion(repeatTime=int(theseRepTimes[i]),\
                                  oldDD=oldDD,s=s, meanG=meanG,\
                                  stdG=stdG, Y=Y, SPP=SPP,POP1=1000, \
                                  TIME=TIME, printStuff=False, printFig=False)


res=np.mean(results,1)

results2=np.zeros([len(theseRepTimes),REPS])
for r in range(REPS):
    print(f'Rep={r}')
    for i in range(len(theseRepTimes)):
        results2[i,r]=ann.invasion(repeatTime=int(theseRepTimes[i]),\
                                  oldDD=oldDD2,s=s, meanG=meanG,\
                                  stdG=stdG, Y=Y, SPP=SPP,POP1=1000, \
                                  TIME=TIME, printStuff=False, printFig=False)

res2=np.mean(results2,1)


##saving everything
np.savez(fileName+'.npz', results=results, s=s, meanG=meanG, stdG=stdG, \
         POP1=POP1,SPP=SPP,TIME=TIME,Y=Y, REPS=REPS, oldDD=oldDD, res=res,
         theseRepTimes=theseRepTimes, results2=results2, oldDD2=oldDD2)


plt.plot(theseRepTimes,res,'ko-')
plt.plot(theseRepTimes,res2,'ro-')
plt.show()
##
