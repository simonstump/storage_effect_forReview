import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

x=np.load('save_annual_survive.npz')

REPS=x['REPS']
TIME=x['TIME']
GodoyRes=x['GodoyRes']
GodoyResNeut=x['GodoyResNeut']
AngertRes=x['AngertRes']
AngertResNeut=x['AngertResNeut']
ChessRes=x['ChessRes']
ChessResNeut=x['ChessResNeut']
##Chess2Res=x['Chess2Res']
##Chess2ResNeut=x['Chess2ResNeut']
##Chess3Res=x['Chess3Res']
##Chess3ResNeut=x['Chess3ResNeut']



fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

plt.xlabel("time") ;
plt.ylabel("species richness");
daX = np.arange(0,TIME+1);

ax.plot(daX ,np.mean(GodoyRes,1),'b-')
ax.plot(daX ,np.mean(GodoyResNeut,1),'r-')
plt.legend(['Storage','Neutral'])
plt.title('Sedgwick Reserve data')
ax.set_xscale('log')
plt.savefig(f'annual_survive_Godoy_data.png');

plt.show()


fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

plt.xlabel("time") ;
plt.ylabel("species richness");
daX = np.arange(0,TIME+1);

ax.plot(daX ,np.mean(AngertRes,1),'b-')
ax.plot(daX ,np.mean(AngertResNeut,1),'r-')
plt.legend(['Storage','Neutral'])
plt.title('Tumamoc Hill data')
ax.set_xscale('log')
plt.savefig(f'annual_survive_Angert_data.png');




fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

plt.xlabel("time") ;
plt.ylabel("species richness");
daX = np.arange(0,TIME+1);

ax.plot(daX ,np.mean(ChessRes,1),'b-')
ax.plot(daX ,np.mean(ChessResNeut,1),'r-')
plt.legend(['Storage','Neutral'])
plt.title(f'Portal data')
ax.set_xscale('log')
plt.savefig(f'annual_survive_Chesson_data.png');


##fig = plt.figure()
##ax = fig.add_subplot(1, 1, 1)
##
##plt.xlabel("time") ;
##plt.ylabel("species richness");
##daX = np.arange(0,TIME+1);
##
##ax.plot(daX ,np.mean(Chess2Res,1),'b-')
##ax.plot(daX ,np.mean(Chess2ResNeut,1),'r-')
##plt.legend(['Storage','Neutral'])
##plt.title(f'Portal data, G=0.65')
##ax.set_xscale('log')
##plt.savefig(f'annual_survive_Chesson_data2.png');
##
##
##fig = plt.figure()
##ax = fig.add_subplot(1, 1, 1)
##
##plt.xlabel("time") ;
##plt.ylabel("species richness");
##daX = np.arange(0,TIME+1);
##
##ax.plot(daX ,np.mean(Chess3Res,1),'b-')
##ax.plot(daX ,np.mean(Chess3ResNeut,1),'r-')
##plt.legend(['Storage','Neutral'])
##plt.title(f'Portal data, G=0.3')
##ax.set_xscale('log')
##plt.savefig(f'annual_survive_Chesson_data3.png');
##
