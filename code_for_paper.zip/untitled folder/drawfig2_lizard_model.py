import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt


x=np.load('save_lizard_model_results.npz')

results=x['results']
Avals=x['Avals']
meanN=x['meanN']
delta=x['delta']
Evar=x['Evar']
REPS=x['REPS']
res=x['res']
res0=x['res0']
zeroVal=x['zeroVal']



plt.plot(np.exp(Avals),res,'ko-')#,Avals,Avals*0+res0/2,'r--')

plt.xscale('log')

plt.xlabel("Relative impact of adults",fontsize=14);
plt.ylabel("Stabilizing mechanism",fontsize=14);



plt.savefig(f'lizard_results.png')
plt.show()
