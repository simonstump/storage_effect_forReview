import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile


'''
This code runs takes the output of of run_annua-slowComp.py and
draws Fig. S1
'''

x=np.load('annual_slowComp.npz')

results=x['results']
s=x['s']
meanG=x['meanG']
stdG=x['stdG']
POP1=x['POP1']
SPP=x['SPP']
TIME=x['TIME']
Y=x['Y']
REPS=x['REPS']
theseDD=x['theseDD']
res=x['res']



plt.plot(theseDD,res,'ko-')

plt.xlabel('Fraction of competition from last year')
plt.ylabel('Storage effect')

plt.savefig('annual_slowComp.png')
