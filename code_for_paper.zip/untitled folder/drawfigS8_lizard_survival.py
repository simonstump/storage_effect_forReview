import pandas as pd
import numpy as np
import math
import pylab
from matplotlib import pyplot as plt



x=np.load('save_var_lizard_death.npz')

storage=x['storage']
neutral=x['neutral']
storage2=x['storage2']
storageX=x['storageX']
neutralX=x['neutralX']
storage2X=x['storage2X']
Evar2=x['Evar2']
TIME=x['TIME']
delta=1-x['delta']
Evar=x['Evar']
adultVjuv=x['adultVjuv']
SPP=x['SPP']
meanN=x['meanN']
GENS=x['GENS']


plt.plot(delta ,np.mean(storage2,0),'ko-')
plt.plot(delta ,np.mean(storage,0),'ro-')
plt.plot(delta ,np.mean(neutral,0),'bo-')

plt.xlabel('Adult survival',fontsize=14)
plt.ylabel('Species richness',fontsize=14)

daNames=['high variation','low variation','neutral']

plt.legend(labels=daNames)
plt.title(f'Impact on lizard persistence, low adult impact')
plt.savefig(f'lizard_survival.png')


plt.show();

plt.plot(delta ,np.mean(storage2X,0),'ko-')
plt.plot(delta ,np.mean(storageX,0),'ro-')
plt.plot(delta ,np.mean(neutralX,0),'bo-')

plt.xlabel('Adult survival',fontsize=14)
plt.ylabel('Species richness',fontsize=14)

daNames=['high variation','low variation','neutral']

plt.legend(labels=daNames)
plt.title(f'Impact on lizard persistence, moderate adult impact')
plt.savefig(f'lizard_survival2.png')



plt.show();

