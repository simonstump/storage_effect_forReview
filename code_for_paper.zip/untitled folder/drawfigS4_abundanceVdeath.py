import pandas as pd
import numpy as np
import math
import pylab
from matplotlib import pyplot as plt



x=np.load('save_abundance_v_death.npz')

resultsStorage=x['resultsStorage']
resultsNeutral=x['resultsNeutral']
resultsPredators=x['resultsPredators']
Nval=np.exp(x['Nval'])
TIME=x['TIME']
death=x['death']
MECH_STRENGTH=x['MECH_STRENGTH']


TIME=len(resultsStorage)-10

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

#daX = np.arange(0,TIME);
plt.plot(Nval ,resultsStorage[:,TIME],'k-')
plt.plot(Nval ,resultsNeutral[:,TIME],'b-') 
plt.plot(Nval ,resultsPredators[:,TIME],'g-')

ax.set_xscale('log')
plt.xlabel('Mean population levels',fontsize=14)
plt.ylabel('Species richness',fontsize=14)

#plt.xlim(10,TIME*death)

daNames=['Storage effect','Neutral model',\
                   'Predator partitioning']

plt.legend(labels=daNames)
plt.title(f'Community size, K')
plt.savefig(f'abundance_v_death.png')
