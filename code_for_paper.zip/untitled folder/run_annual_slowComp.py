import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

'''
Run this code to generate the Fig. S1.
'''


fileName='save_annual_slowComp';

#The parameters
s=.6;
meanG=.5;
stdG=.2;
POP1=1000;
SPP=3;
TIME=2000;
Y=3;
printStuff=False;
printFig=False;
oldDD=0;

REPS=35;

#This is the # of competition that occurred last year
theseDD=np.arange(0,1.001,.05)

#This imports the model that actually runs the simulation
import annual_slowComp as ann

results=np.zeros([len(theseDD),REPS])

for r in range(REPS):
    print(f'Rep={r}')
    for i in range(len(theseDD)):
        results[i,r]=ann.invasion(oldDD=theseDD[i],s=s, meanG=meanG,\
                              stdG=stdG, Y=Y, SPP=SPP,POP1=1000, \
                              TIME=TIME, printStuff=False, printFig=False)


res=np.mean(results,1)

##saving everything
np.savez(fileName+'.npz', results=results, s=s, meanG=meanG, stdG=stdG, \
         POP1=POP1,SPP=SPP,TIME=TIME,Y=Y, REPS=REPS, theseDD=theseDD, res=res)


plt.plot(theseDD,res,'ko-')
plt.show()
