import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

x=np.load('save_lizard_autocorr.npz')

results=x['results']
results2=x['results2']
meanN=x['meanN']
delta=x['delta']
Evar=x['Evar']
adultVjuv=x['adultVjuv']
adultVjuv2=x['adultVjuv2']
theseRepTimes=x['theseRepTimes']

res=np.mean(results,1)
res2=np.mean(results2,1)


plt.plot(theseRepTimes,res,'ko-')
plt.plot(theseRepTimes,res2,'ro-')

plt.xlabel("Autocorrelation");
plt.ylabel("Invader growth rate");

plt.legend(['Competition from adults','Competition from juveniles'])
plt.savefig('lizard_autocorr.png')
plt.show()


