import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile


x=np.load('save_var_lotteryVdeath_10spp.npz')

results=x['results']
Evars=x['Evars']
deaths=x['deaths']
TIME1=x['TIME1']
POP1=x['POP1']

SPP=10

plt.xlabel("Death rate, $\delta$") ;
plt.ylabel("Species richness");
for i in range(len(Evars)):
   plt.plot(deaths ,results[i,:],'o-')

plt.legend(['Neutral model','Low variation','High variation'])
plt.title(f'{SPP} species lottery model')



plt.savefig('lottery_v_death10.png')
