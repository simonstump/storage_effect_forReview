import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt


printStuff=False


#Here are the parameters for the lizard model.

meanN=100;
delta=.3;
adultVjuv=10; #if this is 3, then 1 adult has the same impact as 3 juveniles.
Evar=.5
INVASION=True

def lizard_model(meanN=100, delta=.3, adultVjuv=10, Evar=.5, \
                 repeatTime=2, INVASION=True,printStuff=False):

#if(True):

    alphaA=-adultVjuv*np.log(delta)/(meanN*(1+adultVjuv));
    alphaJ=alphaA/adultVjuv;


    N=[0, meanN]

    if(INVASION):
        N=[0,meanN]
        TIME=15000;
    else:
        N=[meanN/2,meanN/2]
        TIME=200;


    #This is the growth response each year.
    #E[i,j] is the E value for sp. j in year i.
    E=np.random.normal(0,Evar,[round(TIME/repeatTime),2])



    #Here are the variables for saving the data.
    Nrecord=np.zeros(shape=[TIME,2])
    lamrecord=np.zeros(shape=[TIME,2])
    birthRecord=np.zeros(shape=[TIME,2]);
    compRecord=np.zeros(shape=[TIME,2]);


    t=0

    for env in range(round(TIME/repeatTime)):
        for tt in range(repeatTime):
            
            if(printStuff):
                print('\n ==================== \n')
                print(f'N={N}')
                print(f'E(env)={E[env,:]}')

            #Amount of competition that year
            compA=alphaA*sum(N)
            compJ=alphaJ*sum(N*(np.exp(E[env,:])));

            #number of tadpoles that recruit per capita
            births=np.exp(E[env,:]-compA-compJ);

            lam=1-delta+births

            N=N*lam

            Nrecord[t,:]=N;
            lamrecord[t,:]=lam;
            birthRecord[t,:]=births;
            compRecord[t,0]=compA;
            compRecord[t,1]=compJ;

            t+=1;
            
            if(printStuff):
                print(f'comp={compA}, {compJ}')
                print(f'births={births}')
                print(f'lambda={lam}')
                print(f'N={N}')

        

        
    #print(N)


    if(INVASION):
        r=sum(np.log(lamrecord))/TIME;
        return r[0]
    else:
        plt.xlabel("time") ;
        plt.ylabel("density");
        daX = np.arange(0,TIME);
        plt.plot(daX ,Nrecord)
        plt.show();
        return N
