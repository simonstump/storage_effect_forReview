import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile
from scipy.special import lambertw


#This is the survival model when species are partitioning habitat.  It
#assumes there is enough dispersal that only a spatial storage effect occurs.

TIME=50#000;
SPP=6;
death=.2;
POP1=100#1000;
POP=POP1*SPP;
REPS=1;
VAR_E=.4;
habitatSize=10;
printStuff=True;
printFig=False;
drawNfig=False;

def survival_time(death=.2,SPP=10,POP1=100, VAR_E=.4, TIME=20000, \
                  REPS=10, printStuff=False, printFig=True, \
                  habitatSize=50, drawNfig=False):
#if(True):
    POP=POP1*SPP;
    recD=np.zeros(shape=[TIME+1,REPS]);

    if(drawNfig):
        recN=np.zeros(shape=[TIME+1,SPP]);
        recN[0,:]=POP1;

    #the number of habitat types
    Nhabitat=100#round(POP1/habitatSize)
    
    
    for rep in range(REPS):

        print(f'Replicate #{rep}')
        N=np.full(SPP,POP1);

        temp=np.exp(np.random.normal(1,1,SPP))
        for i in range(SPP):
            N[i]=max(int(temp[i]/sum(temp)*POP1*SPP), 20);
            
        #theSTD=np.real(lambertw(VAR_E))
        ##Birth rates at each time step, which are random
        #E1=np.random.normal(0,theSTD**(.5),[Nhabitat,SPP])
        #
        ##Here I make sure the means are the same.
        #E2=np.subtract(E1,np.mean(E1,0));
        #
        #E=np.exp(E2)

        E=np.random.poisson(1/VAR_E,[Nhabitat,SPP])*VAR_E;

        #Just divide by the sum of E!!!
        
        E=E-np.mean(E,0)+1;
        E[E<0]=0;

        E=E-np.mean(E,0)+1;
        E[E<0]=0;


        #print(E)
        #plt.ylabel("density");
        #plt.show();

        
        #recD measures diversity at each time step
        recD[0,rep]=SPP;


        for t in range(TIME):

            if(printStuff):
                print('\n ==================== \n')
                print(f'N={N}')


            #number of adults that survive
            survive=np.random.binomial(N,(1-death));

            #Each individual produces the same number of offspring
            births=N*E;

            #Total number of births in each habitat type (summed over sp.)
            total_births=births.sum(1);

            #openSites is the expected total number of recruitment events
            #per habitat
            openSites=(POP-sum(survive))/Nhabitat;
            

            #meanBirths is the chance an individual newborn will recruit to
            #adulthood in each habitat type
            meanBirths=np.divide(openSites,total_births);

            #This repeats meanBirths to make it a (habitat, spp)-sized matrix
            meanBirths2=np.ndarray([Nhabitat,SPP],buffer=np.repeat(meanBirths,SPP));


            #recruit is the number of births that become adults
            recruit=np.random.poisson(np.sum(births*meanBirths2,0));
            #recruit2=np.sum(recruit,0);

            N=survive+recruit;

            recD[t+1,rep]=sum(N>0);

            if(drawNfig):
                recN[t+1,:]=N;
            
            if(printStuff):
                print(f'(Replicate {rep}, time {t}')
                print(f'survival={survive}')
                print(f'open sites={openSites}')
                print(f'expect recr={births*np.sum(meanBirths2,0)}')
                print(f'recruitment={recruit}')
                print(f'total recruit={sum(recruit)}')
                print(f'N={N}')
                print(f'Total pop = {np.sum(N)}')
                print('recoded={recD[t+1,rep]}')

        if(drawNfig):
            fig=plt.figure();
            plt.xlabel("time") ;
            plt.ylabel("density");
            daX = np.arange(0,TIME+1);
            plt.plot(daX ,np.log(recN))
            fig.savefig(f'plot{rep}.png')



    if(printFig):
        fig=plt.figure();
        plt.xlabel("time") ;
        plt.ylabel("density");
        daX = np.arange(0,TIME+1);
        plt.plot(daX ,np.mean(recD,1))
        plt.show();

    return recD

#plt.xlabel("time") ;
#plt.ylabel("density");
#daX = np.arange(0,TIME+1);
#plt.plot(daX ,recN)
#plt.show();

    
