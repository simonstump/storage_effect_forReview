import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile
from scipy.special import lambertw





def survival_time(death=.2,SPP=10,POP1=1000, VAR_E=.5, TIME=20000, \
                  REPS=10, printStuff=False, printFig=True):
    POP=POP1*SPP;
    recD=np.zeros(shape=[TIME+1,REPS]);
    #recN=np.zeros(shape=[TIME+1,SPP]);

    for rep in range(REPS):

        print(f'Replicate #{rep}')
        N=np.full(SPP,POP1);

        temp=np.exp(np.random.normal(1,1,SPP))
        for i in range(SPP):
            N[i]=max(int(temp[i]/sum(temp)*POP1*SPP), 20);

        if printStuff:
            print(N)
            print(type(N))

        theSTD=np.real(lambertw(VAR_E))
        #Birth rates at each time step, which are random
        E1=np.random.normal(loc=0,scale=(theSTD**(.5)),size=[TIME,SPP])
        E=np.exp(E1)

        #recD measures diversity at each time step
        recD[0,rep]=SPP;

        for t in range(TIME):

            if(printStuff):
                print('\n ==================== \n')
                print(f'N={N}')

            #number of adults that survive
            survive=np.random.binomial(N,(1-death));

            #Each individual produces the same number of offspring
            births=N*E[t,:];

            #openSites is the expected total number of recruitment events
            openSites=POP-sum(survive);
            
            #meanBirths is the chance an individual newborn will recruit to adulthood
            meanBirths=max(openSites/sum(births),0);

            #if(printStuff):
            #    print(f'births per individual={births}')
            #    print(f'live={(1-death)}')

            #recruit is the number of births that become adults
            recruit=np.random.poisson(births*meanBirths);

            N=survive+recruit;

            recD[t+1,rep]=sum(N>0);
            #recN[t+1,:]=N;
            
            if(printStuff):
                print(f'(Replicate {rep}, time {t}')
                print(f'survival={survive}')
                print(f'open sites={openSites}')
                print(f'meanRecruit={births*meanBirths}')
                print(f'recruitment={recruit}')
                print(f'total recruit={sum(recruit)}')
                print(f'N={N}')
                print('recoded={recD[t+1,rep]}')

            



    if(printFig):
        plt.xlabel("time") ;
        plt.ylabel("density");
        daX = np.arange(0,TIME+1);
        plt.plot(daX ,np.mean(recD,1))
        plt.show();

    return recD
