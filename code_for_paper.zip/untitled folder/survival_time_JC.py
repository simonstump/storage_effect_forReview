import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile


#This is the survival model when species are partitioning natural enemies.


def survival_time(death=.2,SPP=10,POP1=1000, alpha=.4, TIME=20000, \
                  REPS=10, printStuff=False, printFig=True):

    POP=POP1*SPP;
    recD=np.zeros(shape=[TIME+1,REPS]);
    #recN=np.zeros(shape=[TIME+1,SPP]);

    for rep in range(REPS):

        print(f'Replicate #{rep}')
        N=np.full(SPP,POP1);

        temp=np.exp(np.random.normal(1,1,SPP))
        for i in range(SPP):
            N[i]=max(int(temp[i]/sum(temp)*POP1*SPP), 20);

        #recD measures diversity at each time step
        recD[0,rep]=SPP;

        for t in range(TIME):

            if(printStuff):
                print('\n ==================== \n')
                print(f'N={N}')


            #number of adults that survive
            survive=np.random.binomial(N,(1-death));

            #openSites is the expected total number of recruitment events
            openSites=POP-sum(survive);

            #chance a seed is killed by species-specific enemies
            JCeffect=N/POP*alpha;

            #Births once species-specific mortality is factored in
            births=N*(1-JCeffect);
            
            #the chance an individual newborn will recruit to adulthood
            meanBirths=max(openSites/sum(births),0);

            #recruit is the number of births that become adults
            recruit=np.random.poisson(births*meanBirths);

            N=survive+recruit;

            recD[t+1,rep]=sum(N>0);
            #recN[t+1,:]=N;
            
            if(printStuff):
                print(f'(Replicate {rep}, time {t}')
                print(f'survival={survive}')
                print(f'open sites={openSites}')
                print(f'J.C. effects={JCeffect}')
                print(f'Seedling mortality={np.exp(-JCeffect)}')
                print(f'meanRecruit={births*meanBirths}')
                print(f'recruitment={recruit}')
                print(f'total recruit={sum(recruit)}')
                print(f'N={N}')
                print('recoded={recD[t+1,rep]}')

            



    if(printFig):
        plt.xlabel("time") ;
        plt.ylabel("density");
        daX = np.arange(0,TIME+1);
        plt.plot(daX ,np.mean(recD,1))
        plt.show();

    return recD
