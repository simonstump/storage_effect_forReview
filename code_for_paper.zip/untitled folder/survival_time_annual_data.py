import pandas as pd
import numpy as np
import math

name='Godoy'
REPS=10
printFig=True,
TIME=1000

import survival_time_annual as ann

def survival_time(REPS=10, name='Godoy',printFig=False,TIME=1000,neutral=False):



    print(name)
    POP1=1000;
    SPP=10;

    if name=='Godoy':
        s=0.43;
        meanG=0.04;
        Y=1775.0;
        #stdG=meanG;

    if name=='Angert':
        s=0.41;
        meanG=0.45;
        Y=1700;
        #stdG=meanG;

    if name=='Chesson':
        s=0.67;
        meanG=0.5;
        Y=1700;
        #stdG=meanG;

    if name=='Chesson2':
        s=0.67;
        meanG=0.65;
        Y=1700;
        #stdG=meanG;
    if name=='Chesson3':
        s=0.67;
        meanG=0.3;
        Y=1700;
        #stdG=meanG;


    #if lowVar==True:

    stdG=meanG/2;

    if neutral==True:
        stdG=0;

    results = np.zeros([REPS,TIME])

    results= ann.survival_time(s=s, meanG=meanG, stdG=stdG, Y=Y,\
                  SPP=SPP,POP1=POP1, TIME=TIME, \
                  REPS=REPS, printStuff=False, printFig=printFig)


    return results
