import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt




s=.6
meanG=.4
stdG=.2
Y=10
SPP=10
POP1=1000
TIME=1000
oldDD=.5
REPS=1#20
repeatTime=4
printStuff=False
printFig=True


def survival_time(s=.6, meanG=.4, stdG=.2, Y=3,\
                  SPP=10,POP1=1000, TIME=2000, \
                  oldDD=.5, REPS=2, repeatTime=4,\
                  printStuff=False, printFig=False):


    POP=POP1*SPP;
    recD=np.zeros(shape=[round(TIME/repeatTime)*repeatTime+1,REPS]);
    #recN=np.zeros(shape=[TIME+1,SPP]);
    #recN[0,:]=POP1;

    #q is the competition coeifficent.  here I calculate it to keep
    #population densities about constant.
    beta=1-s*(1-meanG)
    q=(meanG*Y/beta-1)/(POP);

    for rep in range(REPS):

        print(f'Replicate #{rep}')
        N=np.full(SPP,int(POP/SPP));
        for i in range(SPP):
            N[i]=min(int(np.exp(np.random.normal(np.log(POP1),np.log(POP1)/4))), 25)

        #Germination at each time step, either a good or bad year with
        # equal probability.
        #Here we assume that germination is recorded on the log scale for data.
        E1=np.random.binomial(1,.5,[TIME,SPP])
        G=meanG+stdG*(1-2*E1)

        if(np.min(G)<0):
            print('ERROR!!!\nvarG is too big for that meanG')
            break;

        #recD measures diversity at each time step
        recD[0,rep]=SPP;

        plantOld=N*meanG
        recVal=0;
        for t in range(round(TIME/repeatTime)):
            for tt in range(repeatTime):

                if(printStuff):
                    print('\n ==================== \n')
                    print(f'N={N}')

                #number of germinants
                plants=N*G[t,:]

                #how much competition reduces fecundity
                comp=1+q*sum(plants)*(1-oldDD)+q*sum(plantOld)*oldDD;

                plantOld=plants
                
                #number of seeds entering seed bank
                recruit=np.random.poisson(Y*plants/comp);


                #print(f'\n\nG={G[t,:]},\nN={N},\ns={s}')
                #survive is seedbank survival
                if(printStuff):
                    print(f'germination={G[t,:]}')
                    print(f'Survival prob={(1-G[t,:])*s}')
                survive=np.random.binomial(N,(1-G[t,:])*s);

                N=survive+recruit;

                recVal+=1;
                recD[recVal,rep]=sum(N>0);
                
                if(printStuff):
                    print(f'(Replicate {rep}, time {t}')
                    print(f'plant={plants}')
                    print(f'old plant={plantOld}')
                    print(f'Not germinating={N*(1-G[t,:])}')
                    print(f'survival={survive}')
                    print(f'expected_recruit={Y*plants/comp}')
                    print(f'Plants={plants}')
                    print(f'recruitment={recruit}')
                    print(f'total recruit={sum(recruit)}')
                    print(f'N={N}')
                    print('recoded={recD[t+1,rep]}')

            


    #daX = np.arange(0,TIME+1);
    #plt.plot(daX ,recN)
    #plt.show();

    if(printFig):
        fig = plt.figure()
        ax = fig.add_subplot(1, 1, 1)

        plt.xlabel("time") ;
        plt.ylabel("density");
        daX = np.arange(0,TIME+1);

        ax.plot(daX ,np.mean(recD,1))
        ax.set_xscale('log')
        #plt.savefig(f'annual_survive_{name}_data.png');

        plt.show();

    return recD
