import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt



DIF=.1;
delta=.4;
Rin=1;
STD=0.1;
c=1;
a=1;
plotIt=True;
plotName='test'

def invader_growth(DIF=.1,c=1,a=1,delta=.4,Rin=1,STD=.1,plotIt=False,\
                   plotName='test'):
#if(True):
    seed=34138.13824
    seed2=.284018
    Evals1=np.arange(0,1.000001,.001)#.0001)
    Evals2=np.mod(Evals1*seed+seed2,1)
    Evals2=Evals2-np.mean(Evals2)+.5

    L=len(Evals1);

    cprime=c*(1-DIF)
    
    c_r=cprime + 2*STD*Evals1 - STD
    c_i=c + 2*STD*Evals2 - STD

    ####Sp. 1 is dominant

    Rstar=np.true_divide(delta,a*c_r);
   
    ri2=np.mean(Rstar*c_i*a-delta)

    if(plotIt):
        fig=plt.figure();

        R2star1=np.true_divide(delta,a*c_r);
        R2star2=np.true_divide(delta,a*c_i);
        R1star1=np.true_divide(delta,a*(c_r+c*DIF));
        R1star2=np.true_divide(delta,a*(c_i+c*DIF));

        BIG=1.2
        for i in range(L):
            #print(i/L)
            plt.plot([R1star1[i],R1star1[i],BIG],[BIG,R2star1[i],R2star1[i]],'r-',alpha=.01)
            plt.plot([R1star2[i],R1star2[i],BIG],[BIG,R2star2[i],R2star2[i]],'b-',alpha=.01)


        plt.plot([np.mean(R1star1),np.mean(R1star1),BIG],\
                 [BIG,np.mean(R2star1),np.mean(R2star1)],'r-')
        plt.plot([np.mean(R1star2),np.mean(R1star2),BIG],\
                 [BIG,np.mean(R2star2),np.mean(R2star2)],'b-')

        plt.xlim(0,1)
        plt.ylim(0,1)
        plt.xlabel("Resource 1",fontsize=14);
        plt.ylabel("Resource 2",fontsize=14);

        plt.savefig(plotName);
        

        #plt.show()
    
    return ri2



