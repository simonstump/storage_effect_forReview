import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile

'''
This code simulates competition between annual plants when density-dependence
is delayed, but also there is autocorrelation in the environment.  It
calculates stabilizing mechanisms.
'''


s=.6;
meanG=.5;
stdG=.2;
POP1=1000
SPP=2;
TIME=100;
Y=3;
printStuff=False#True;
printFig=True#False;
oldDD=0;
repeatTime=1#10

def invasion(s=.6, meanG=.4, stdG=.2, Y=3,\
             SPP=2,POP1=1000, TIME=20000, \
             oldDD=.5, repeatTime=2, \
             printStuff=False, printFig=False):

    POP=POP1*(SPP-1);
    recLam=np.zeros(shape=[TIME+1,SPP]);
    recN=np.zeros(shape=[TIME+1,SPP]);
    recN[0,:]=POP1;
    recN[0,0]=0;

    #q is the competition coeifficent.  here I calculate it to keep
    #population densities about constant.
    beta=1-s*(1-meanG)
    q=(meanG*Y-beta)/(POP*meanG*beta);
    print(f'Competition coefficient is {q}')

    N=np.full(SPP,POP1);
    N[0]=0;

    #Germination at each time step, either a good or bad year with
    # equal probability.
    E1=np.random.binomial(1,.5,[round(TIME/repeatTime),SPP])
    G=meanG+stdG*(1-2*E1)

    if(np.min(G)<0):
        print('ERROR!!!\nvarG is too big for that meanG')
        quit;

    plantOld=np.sum(N)*Y*meanG;


    t=0
    for env in range(round(TIME/repeatTime)):

        for tt in range(repeatTime):

            t+=1
            if(printStuff):
                print('\n ==================== \n')
                print(f'N={N}')

            #number of germinants
            plants=N*G[env,:]

            #how much competition reduces fecundity
            comp=1+q*((1-oldDD)*sum(plants)+oldDD*plantOld);


            #lam is the per-capita growth rate
            lam=s*(1-G[env,:])+G[env,:]*Y/comp;
            
            
            N=N*lam;

            recLam[t,:]=lam;
            recN[t,:]=N;

            plantOld=sum(plants)
            
            if(printStuff):
                print(f'Time {t}')
                print(f'Not germinating={N*(1-G[env,:])}')
                print(f'Plants={plants}')
                print(f'N={N}')
                print('recoded={recD[t+1,rep]}')

        


    r=np.log(recLam[round(TIME/2):TIME,:])
    growth=np.mean(r,0)
    #print(growth)
             
    if(printFig):
        daX = np.arange(0,TIME+1);
        plt.plot(daX ,recN)
        plt.show();

    return growth[0]
