import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt


vital=pd.read_csv('godoy_speciesvitalrates.csv')

print(vital)

spp=vital['species']

vital.set_index("species",inplace=True)



alpha=pd.read_csv('godoy_alpha.csv')

print(alpha)

alpha.set_index("species",inplace=True)


#div is the number of species.
div=np.size(spp);


#to call the impact of sp. 1 on sp. 2, write alpha.loc['sp1','sp2']


#Here I estimate the equilibrium density each species would achive if
#it were on its own (nbar), and then calculate cstar as the inverse
#of the amount of competition it would need to experience to be at
#equilibrium.
nbar=np.zeros([div,1])
cstar=np.zeros([div,1])
beta=np.zeros([div,1])

for i in range(div):
    s=spp[i]
    cstar[i]=(1-(1-vital.loc[s,'g'])*vital.loc[s,'s'])/ \
              (vital.loc[s,'g']*vital.loc[s,'lambda'])
    #print(cstar[i])
    nbar[i]=(1/cstar[i]-1)/alpha.loc[s,s]
    #print(nbar[i])
    beta[i]=1
    #vital.loc[s,'s']*vital.loc[s,'g']
    #1-vital.loc[s,'s']*(1-vital.loc[s,'g'])


vital.insert(2,'cstar',cstar)
vital.insert(2,'nbar',nbar)
vital.insert(2,'beta',beta)


#now, I make a vector of all of the fitness differences and stabilizing mechs.
#If there are n species, then there will be (n-1)*n/2 pairs of heterospecifics
#(without repeats).
fit_difs=np.zeros([int((div-1)*div/2),1])
stabs=np.zeros([int((div-1)*div/2),1])
coexist=np.zeros([int((div-1)*div/2),1])

counter=0
for i in range(div):
    for j in range(i+1,div):
        s1=spp[i]
        s2=spp[j]

##        grow1=np.log( (1-vital.loc[s1,'g'])*vital.loc[s1,'s']+ \
##                      vital.loc[s1,'lambda']*vital.loc[s1,'g']/ \
##                      (1+alpha.loc[s1,s2]*vital.loc[s2,'nbar'])) \
##                      /vital.loc[s1,'beta']
##        #print(f'{s1} has a growth rate of {grow1} vs. {s2}')
##
##        grow2=np.log( (1-vital.loc[s2,'g'])*vital.loc[s2,'s']+ \
##                      vital.loc[s2,'lambda']*vital.loc[s2,'g']/ \
##                      (1+alpha.loc[s2,s1]*vital.loc[s1,'nbar'])) \
##                      /vital.loc[s2,'beta']
##        #print(f'{s2} has a growth rate of {grow2} vs. {s1}')
##
        grow1=np.log( (1-vital.loc[s1,'g'])*vital.loc[s1,'s']+ \
                      vital.loc[s1,'lambda']*vital.loc[s1,'g']/ \
                      (1+alpha.loc[s2,s1]*vital.loc[s2,'nbar'])) \
                      /vital.loc[s1,'beta']
        #print(f'{s1} has a growth rate of {grow1} vs. {s2}')

        grow2=np.log( (1-vital.loc[s2,'g'])*vital.loc[s2,'s']+ \
                      vital.loc[s2,'lambda']*vital.loc[s2,'g']/ \
                      (1+alpha.loc[s1,s2]*vital.loc[s1,'nbar'])) \
                      /vital.loc[s2,'beta']
        #print(f'{s2} has a growth rate of {grow2} vs. {s1}')

        stabs[counter]=(grow1+grow2)/2
        fit_difs[counter]=(grow1-grow2)/2
        coexist[counter]=min(grow1,grow2)>0
        counter+=1
        
print(f'mean stabiliting mechanism = {np.nanmean(stabs)}')
print(f'mean fitness difference = {np.nanmean(abs(fit_difs))}')
print(f'variance in fitness differences is = {np.nanvar(fit_difs)}')
print(f'fraction of spp. persisting = {np.nanmean(coexist)}')
print('\n')
print(f"mean germination = {np.mean(vital.loc[:,'g'])}")
print(f"variance in germination = {np.var(vital.loc[:,'g'])}")
print(f"mean survival = {np.mean(vital.loc[:,'s'])}")
print(f"mean alpha = {np.nanmean(alpha)}")
print(f"mean yield = {np.mean(vital.loc[:,'lambda'])}")
