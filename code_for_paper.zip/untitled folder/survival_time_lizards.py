import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile


printStuff=False


#Here are the parameters for the lizard model model.

##delta=.3
##Evar=.5
##INVASION=True
##adultVjuv=5
##meanN=1000
##TIME = 1000
##SPP=4
##REPS=100;
##printStuff=False


def lizard_model(meanN=1000, delta=.3, adultVjuv=10, Evar=.5, \
                 TIME=1000, SPP=4, printStuff=False):


    alphaA=-adultVjuv*np.log(delta)/(meanN*(1+adultVjuv));
    alphaJ=alphaA/adultVjuv;
    


    forStart = np.exp(np.random.normal(0,2,SPP))
    forStart2=20+(meanN-20*SPP)*forStart/sum(forStart)
    N=np.array(np.round(forStart2))
    #N=[round(meanN/2),round(meanN/2)]
    #N=np.ones([1,SPP])*round(meanN/SPP)
    

    #This is the growth response each year.
    #E[i,j] is the E value for sp. j in year i.
    #E=np.random.normal(0,Evar,[round(TIME),2])
    E=np.random.normal(0,Evar,[round(TIME),SPP])





    #Nrecord=np.zeros(shape=[TIME+1,2])
    Nrecord=np.zeros(shape=[TIME+1,SPP])
    Nrecord[0,:]=N
    t=0

    for env in range(TIME):
        
        if(printStuff):
            print('\n ==================== \n')
            print(f'time={env}')
            print(f'N={N}')
            print(f'E(env)={E[env,:]}')

        #Amount of competition that year
        compA=alphaA*sum(N)
        compJ=alphaJ*sum(N*(np.exp(E[env,:])));

        #number of tadpoles that recruit per capita
        births=np.random.poisson(np.exp(E[env,:]-compA-compJ)*N);

        deaths=np.random.binomial(N.astype(int),delta);

        N=N+births-deaths

        Nrecord[t+1,:]=N;

        t+=1;
        
        if(printStuff):
            print(f'comp={compA}, {compJ}')
            print(f'births={births}')
            print(f'deaths={deaths}')
            print(f'N={N}')
            

    

    if(printStuff):
        print(f"output={sum(N>0)}")
        plt.xlabel("time") ;
        plt.ylabel("density");
        daX = np.arange(0,TIME+1);
        plt.plot(daX ,Nrecord)
        plt.show();

    #print(N)
    return(sum(N>0))


    








