import pandas as pd
import numpy as np
import math
from matplotlib import pyplot as plt
from tempfile import TemporaryFile


'''
This generates the data for Figure S7.
'''

fileName='save_annual_survive';


REPS=100

TIME=5000

import survival_time_annual_data as ann


GodoyRes=ann.survival_time(REPS=REPS, name='Godoy',printFig=False,TIME=TIME)
GodoyResNeut=ann.survival_time(REPS=REPS, name='Godoy',printFig=False,TIME=TIME,neutral=True)


AngertRes=ann.survival_time(REPS=REPS, name='Angert',printFig=False,TIME=TIME)
AngertResNeut=ann.survival_time(REPS=REPS, name='Angert',printFig=False,TIME=TIME,neutral=True)


ChessRes=ann.survival_time(REPS=REPS, name='Chesson',printFig=False,TIME=TIME)
ChessResNeut=ann.survival_time(REPS=REPS, name='Chesson',printFig=False,TIME=TIME,neutral=True)

##Chess2Res=ann.survival_time(REPS=REPS, name='Chesson2',printFig=False,TIME=TIME)
##Chess2ResNeut=ann.survival_time(REPS=REPS, name='Chesson2',printFig=False,TIME=TIME,neutral=True)
##Chess3Res=ann.survival_time(REPS=REPS, name='Chesson3',printFig=False,TIME=TIME)
##Chess3ResNeut=ann.survival_time(REPS=REPS, name='Chesson3',printFig=False,TIME=TIME,neutral=True)

##saving everything
np.savez(fileName+'.npz', REPS=REPS, TIME=TIME,GodoyRes=GodoyRes, \
         GodoyResNeut=GodoyResNeut, AngertRes=AngertRes, \
         AngertResNeut=AngertResNeut, ChessRes=ChessRes, \
         ChessResNeut=ChessResNeut)#, Chess2Res=Chess2Res, \
         #Chess2ResNeut=Chess2ResNeut, Chess3Res=Chess3Res, \
         #Chess3ResNeut=Chess3ResNeut )



import draw_annual_surviveData
